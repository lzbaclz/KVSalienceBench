"""NativeServingPolicy — a KV selector trained on the SERVING oracle (not offline
trace labels), using three decision-time features H2O ignores:

    within_accum : H2O-style mean attention over the block's full history (H2O's signal)
    native_cross : 1 if the block was in the previous layer's top-r by real attention
                   (the simulator injects this as `in_prev_topr`; free at decode time)
    recency      : exp(-steps_since_top_k / tau)

The capstone (\\S transfer-gap) shows an OFFLINE-trained scorer collapses to AUC 0.64
on the serving oracle. Trained on the serving oracle with these features, a linear
model reaches AUC ~0.88-0.93 and BEATS H2O (accumulation alone, AUC ~0.84) at
aggressive budgets — and transfers across architectures (train on one model, deploy
on others). H2O loses because it ignores the cross-layer structure and recency that
the served oracle depends on; this policy adds exactly those, for free.

Selection is rank-based, so the linear score w.[accum,cross,recency]+b is applied
directly (no per-step normalisation needed). Weights come from a JSON checkpoint
(`native_serving_scorer.json`, keys: weights=[w_within, w_cross, _, w_recency], bias).
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from seer.policy.base import KVPolicy


class NativeServingPolicy(KVPolicy):
    name = "native"

    def __init__(self, w_within, w_cross, w_recency, bias=0.0,
                 sink: int = 4, window: int = 4, w_recency_tau: float = 64.0) -> None:
        self.w_within = float(w_within)
        self.w_cross = float(w_cross)
        self.w_recency = float(w_recency)
        self.b = float(bias)
        self.sink = int(sink)
        self.window = int(window)
        self.tau = float(w_recency_tau)
        self.r_cross = 0.10   # so the sim injects in_prev_topr at the same top-r

    @classmethod
    def from_ckpt(cls, path: str, **kw) -> "NativeServingPolicy":
        o = json.loads(Path(path).read_text())
        w = o["weights"]            # [w_within_accum, w_native_cross, _, w_recency]
        b = o.get("bias", 0.0)
        return cls(w_within=w[0], w_cross=w[1], w_recency=w[3], bias=float(b), **kw)

    def select_to_keep(self, block_stats, budget, step):
        if not block_stats:
            return set()
        bids = list(block_stats.keys())
        def accum(s):
            h = s.get("attn_history", []) or []
            return float(sum(h) / len(h)) if h else float(s.get("attn_score_now", 0.0))
        x_accum = np.array([accum(block_stats[b]) for b in bids], np.float64)
        x_cross = np.array([float(block_stats[b].get("in_prev_topr", 0.0)) for b in bids], np.float64)
        ssk = np.array([min(float(block_stats[b].get("steps_since_top_k", 1 << 20)), 1e6)
                        for b in bids], np.float64)
        x_rec = np.exp(-ssk / self.tau)
        score = self.w_within * x_accum + self.w_cross * x_cross + self.w_recency * x_rec + self.b

        sorted_bids = sorted(bids)
        forced = set(sorted_bids[: self.sink])
        if self.window > 0:
            forced |= set(sorted_bids[-self.window:])
        remaining = budget - len(forced)
        if remaining <= 0:
            order = sorted_bids[-self.window:][::-1] + sorted_bids[: self.sink] if self.window > 0 \
                else sorted_bids[: self.sink]
            seen, out = set(), []
            for b in order:
                if b not in seen:
                    seen.add(b); out.append(b)
            return set(out[:budget])
        cand = sorted(((b, float(s)) for b, s in zip(bids, score) if b not in forced),
                      key=lambda kv: -kv[1])
        return forced | {b for b, _ in cand[:remaining]}
