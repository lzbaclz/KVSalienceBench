"""Question-aware KV selection (SOTA design candidate).

Motivation. Attention-MAGNITUDE selectors (H2O = cumulative attention + recency,
and the learned within+cross model) all tie at parity because they predict the same
thing: where the model has been attending. They can EVICT a block the *question*
points to whenever that block is not a global heavy-hitter. SnapKV-class methods beat
H2O on long-context QA precisely by anchoring on the question.

The signal: at the first decode step (the question has just been consumed in prefill),
``attn_score_now`` per block is the model's attention *to answer the question* -- a
"question anchor". This is NOT the geometric query-key affinity the paper finds
redundant for predicting future attention; it is the question's actual softmax
attention over the context, and it targets TASK relevance, which (per the paper's own
capstone) attention-magnitude proxies miss.

Policies (matched budget):
  qanchor       : [recency floor] + [top by the frozen step-0 question anchor].
  qanchor_h2o   : [recency floor] + [top by  a*anchor + (1-a)*cumulative]  (fusion).
  snapkv_fixed  : the in-tree SnapKV bug-fix -- prefill anchor + a real recency floor
                  (the original never re-admits generated tokens, so it degenerates).
"""
from __future__ import annotations
from seer.policy.base import KVPolicy


def _recent_floor(block_stats, n_recent: int) -> set:
    ids = sorted(block_stats.keys())
    return set(ids[-n_recent:]) if n_recent > 0 else set()


class QAnchorPolicy(KVPolicy):
    """Question-anchored selection: freeze the step-0 (post-prefill) attention as the
    task-relevance anchor, keep its top blocks + a recency floor. The anchor does not
    drift with decode (unlike H2O's cumulative), so a question-relevant-but-not-heavy
    block is retained."""
    name = "qanchor"

    def __init__(self, recent_frac: float = 0.15, recent_min: int = 8):
        self.recent_frac = float(recent_frac)
        self.recent_min = int(recent_min)
        self._anchor: dict[int, float] = {}

    def reset(self):
        self._anchor = {}

    def _capture_anchor(self, block_stats):
        # accumulate the earliest-seen attention per block as its question anchor
        for bid, st in block_stats.items():
            if bid not in self._anchor:
                self._anchor[bid] = float(st.get("attn_score_now", 0.0))

    def select_to_keep(self, block_stats, budget, step):
        if not block_stats:
            return set()
        if step == 0 or not self._anchor:
            self._anchor = {bid: float(st.get("attn_score_now", 0.0))
                            for bid, st in block_stats.items()}
        else:
            self._capture_anchor(block_stats)  # anchor newly-born blocks at first sight
        n_recent = max(self.recent_min, int(round(self.recent_frac * budget)))
        keep = _recent_floor(block_stats, n_recent) & set(block_stats.keys())
        ranked = sorted((b for b in block_stats if b not in keep),
                        key=lambda b: -self._anchor.get(b, 0.0))
        for b in ranked:
            if len(keep) >= budget:
                break
            keep.add(b)
        return keep


class QAnchorH2OPolicy(KVPolicy):
    """Fusion: keep [recency] + top by (alpha * question-anchor + (1-alpha) *
    cumulative attention). Combines the question signal H2O lacks with H2O's
    decode-time adaptivity."""
    name = "qanchor_h2o"

    def __init__(self, alpha: float = 0.5, recent_frac: float = 0.15, recent_min: int = 8):
        self.alpha = float(alpha)
        self.recent_frac = float(recent_frac)
        self.recent_min = int(recent_min)
        self._anchor: dict[int, float] = {}
        self._cum: dict[int, float] = {}

    def reset(self):
        self._anchor = {}; self._cum = {}

    def select_to_keep(self, block_stats, budget, step):
        if not block_stats:
            return set()
        for bid, st in block_stats.items():
            now = float(st.get("attn_score_now", 0.0))
            if bid not in self._anchor:
                self._anchor[bid] = now
            self._cum[bid] = self._cum.get(bid, 0.0) + now
        # normalize each signal to [0,1] within the live set, then fuse
        live = list(block_stats.keys())
        amax = max((self._anchor[b] for b in live), default=1.0) or 1.0
        cmax = max((self._cum[b] for b in live), default=1.0) or 1.0
        score = {b: self.alpha * self._anchor[b] / amax
                    + (1 - self.alpha) * self._cum[b] / cmax for b in live}
        n_recent = max(self.recent_min, int(round(self.recent_frac * budget)))
        keep = _recent_floor(block_stats, n_recent) & set(live)
        for b in sorted((b for b in live if b not in keep), key=lambda b: -score[b]):
            if len(keep) >= budget:
                break
            keep.add(b)
        return keep


class SnapKVFixedPolicy(KVPolicy):
    """In-tree SnapKV with the recency-floor bug fixed: anchor on the prefill (step-0)
    attention but ALWAYS reserve a recency window so freshly generated tokens are
    re-admitted (the original froze the budget at prefill and never re-admitted, which
    degenerates generation)."""
    name = "snapkv_fixed"

    def __init__(self, recent_frac: float = 0.15, recent_min: int = 8):
        self.recent_frac = float(recent_frac)
        self.recent_min = int(recent_min)
        self._anchor: dict[int, float] = {}

    def reset(self):
        self._anchor = {}

    def select_to_keep(self, block_stats, budget, step):
        if not block_stats:
            return set()
        if not self._anchor:
            self._anchor = {bid: float(st.get("attn_score_now", 0.0))
                            for bid, st in block_stats.items()}
        n_recent = max(self.recent_min, int(round(self.recent_frac * budget)))
        keep = _recent_floor(block_stats, n_recent) & set(block_stats.keys())
        for b in sorted((b for b in block_stats if b not in keep),
                        key=lambda b: -self._anchor.get(b, 0.0)):
            if len(keep) >= budget:
                break
            keep.add(b)
        return keep


class HybridH2OQuestPolicy(KVPolicy):
    """Best-of-both query-aware selection (designed for the selective-retrieval +
    multi-hop regime). H2O's cumulative attention captures persistent / multi-hop
    evidence but misses a query-relevant block that was attended only briefly; Quest's
    current-step attention captures the query-relevant needle but forgets the chain.
    We keep the UNION: sink + recency floor, then split the remaining budget between
    top blocks by *cumulative* attention (H2O signal) and top blocks by *current*
    attention (Quest signal). Nothing is frozen at prefill (re-selected every step),
    so a block can be recalled when the query points to it."""
    name = "qhybrid"

    def __init__(self, sink: int = 4, recent: int = 4, cumulative_frac: float = 0.5):
        self.sink = int(sink)
        self.recent = int(recent)
        self.cf = float(cumulative_frac)

    @staticmethod
    def _cum(st: dict) -> float:
        h = st.get("attn_history")
        return float(sum(h)) if h else float(st.get("attn_score_now", 0.0))

    def select_to_keep(self, block_stats, budget, step):
        if not block_stats:
            return set()
        ids = sorted(block_stats.keys())
        keep = (set(ids[:self.sink]) | set(ids[-self.recent:])) & set(block_stats.keys())
        if len(keep) >= budget:
            return set(list(keep)[:budget])
        remaining = budget - len(keep)
        n_cum = int(round(remaining * self.cf))
        n_cur = remaining - n_cum
        cum_rank = [b for b in sorted(block_stats, key=lambda b: -self._cum(block_stats[b]))
                    if b not in keep]
        for b in cum_rank[:n_cum]:
            keep.add(b)
        cur_rank = [b for b in sorted(
            block_stats, key=lambda b: -float(block_stats[b].get("attn_score_now", 0.0)))
            if b not in keep]
        for b in cur_rank[:n_cur]:
            keep.add(b)
        return set(list(keep)[:budget])
