"""XQP policy — the cross-layer, query-aware fused saliency selector as a
drop-in :class:`seer.policy.base.KVPolicy`.

This is the deployment slot for the XQP predictor (the ICDM "minimal sufficient
model"): a per-block calibrated logistic score over up to four views, then the
standard sink + sliding-window floor and greedy budget fill (mirroring
:class:`seer.policy.seer.SEERPolicy`).

Self-contained (numpy only) so SEER does not import the ``xqp`` package: the
4 closed-form weights + bias are loaded from a JSON checkpoint written by
``xqp.predictor.ClosedFormXQP.save`` (``{"weights": [...], "bias": float}``).

Feature construction from the per-layer ``block_stats`` the simulator provides:
  s_within  : EMA of the block's attention history, normalized by the per-step max.
  s_cross   : 1 if the block was in the PREVIOUS layer's top-r within-EMA set.
              The simulator invokes the policy once per layer in order, and the
              policy object persists across those calls, so we remember the prior
              layer's hot set (InfiniGen's cross-layer premise). Layer 0 uses its
              own top-r (the "no predecessor" convention of the trace extractor).
  s_query   : 0.5 (neutral) — the simulator exposes no per-block query/key, and
              the offline analysis found this view near-irrelevant, so the
              deployed model effectively uses the within+cross pair.
  s_pos     : recency, exp(-steps_since_top_k / w_recency).

Caveat (documented in the paper): the trace-fit weights saw the *true*
per-layer cross indicator; in the aggregated simulator s_cross is reconstructed
from the prior layer's within-EMA top-r, so the deployed scorer is a faithful
but not bit-identical instance of the offline model.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from seer.policy.base import KVPolicy


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


class XQPPolicy(KVPolicy):
    name = "xqp"

    def __init__(
        self,
        weights,
        bias: float = 0.0,
        sink: int = 4,
        window: int = 4,
        r_cross: float = 0.10,
        w_recency: float = 64.0,
        ema_decay: float = 0.9,
        history_k: int = 8,
        lam_io: float = 0.0,
        native_cross: bool = False,
        within_mode: str = "ema",      # "ema" (short EMA) or "accum" (H2O-style full-history mean)
    ) -> None:
        self.w = np.asarray(weights, dtype=np.float32).reshape(-1)
        if self.w.shape[0] != 4:
            raise ValueError(f"XQPPolicy expects 4 weights, got {self.w.shape}")
        self.b = float(bias)
        self.sink = int(sink)
        self.window = int(window)
        self.r_cross = float(r_cross)
        # When True, read s_cross from the simulator's NATIVE prev-layer top-r
        # indicator (`in_prev_topr`, the true offline f_cross) instead of
        # reconstructing it from the previous layer's within-EMA top-r. The
        # offline analysis shows the true cross view adds ~+0.10 recall@budget;
        # the reconstruction throws that away, which is why the deployed model
        # underperforms H2O. Native cross recovers it (free at decode time).
        self.native_cross = bool(native_cross)
        self.within_mode = str(within_mode)
        self.w_recency = float(w_recency)
        self.ema_decay = float(ema_decay)
        self.history_k = int(history_k)
        self.lam_io = float(lam_io)
        self._prev_topr: set[int] = set()
        self._conf: list[float] = []

    @classmethod
    def from_ckpt(cls, path: str, **kwargs) -> "XQPPolicy":
        obj = json.loads(Path(path).read_text())
        w = obj["weights"]
        b = obj["bias"]
        if isinstance(b, list):  # shared bias stored as 0-d list
            b = float(np.asarray(b))
        if np.asarray(w).ndim > 1:
            raise ValueError("XQPPolicy needs the shared (4,) closed form, not per-layer")
        return cls(weights=w, bias=float(b), **kwargs)

    def reset(self) -> None:
        self._prev_topr = set()
        self._conf = []

    def _within_raw(self, hist, now) -> float:
        hist = list(hist)
        if not hist:
            return float(now)
        if self.within_mode == "accum":
            # H2O-style accumulated heavy-hitter: mean attention over the FULL
            # history (rather than a short EMA). The deployed short EMA underranks
            # consistently-attended blocks vs H2O's accumulation, which is the
            # dominant reason the EMA-within deployment trails H2O; this closes it.
            return float(sum(hist)) / float(len(hist))
        tail = hist[-self.history_k:]
        ema = float(tail[0])
        for v in tail[1:]:
            ema = self.ema_decay * ema + (1 - self.ema_decay) * float(v)
        return ema

    def select_to_keep(self, block_stats, budget, step):
        if not block_stats:
            return set()
        bids = list(block_stats.keys())
        within_raw = np.array(
            [self._within_raw(block_stats[b].get("attn_history", []),
                              block_stats[b].get("attn_score_now", 0.0)) for b in bids],
            dtype=np.float32,
        )
        wmax = float(within_raw.max()) + 1e-9
        s_within = within_raw / wmax

        # top-r set of this layer (by within-EMA)
        k = max(1, int(np.ceil(self.r_cross * len(bids))))
        topr_idx = np.argpartition(-within_raw, kth=min(k - 1, len(bids) - 1))[:k]
        cur_topr = {bids[i] for i in topr_idx}

        layer_scalar = float(block_stats[bids[0]].get("layer_scalar", 0.0))
        if self.native_cross and "in_prev_topr" in block_stats[bids[0]]:
            # true prev-layer top-r by real attention, supplied by the simulator
            s_cross = np.array([float(block_stats[b].get("in_prev_topr", 0.0))
                                for b in bids], dtype=np.float32)
        else:
            ref_topr = cur_topr if layer_scalar <= 1e-9 else self._prev_topr
            s_cross = np.array([1.0 if b in ref_topr else 0.0 for b in bids], dtype=np.float32)
        self._prev_topr = cur_topr

        s_query = np.full(len(bids), 0.5, dtype=np.float32)

        ssk = np.array([min(float(block_stats[b].get("steps_since_top_k", 1 << 20)), 1e6)
                        for b in bids], dtype=np.float32)
        s_pos = np.exp(-ssk / self.w_recency).astype(np.float32)

        F = np.stack([s_within, s_cross, s_query, s_pos], axis=1)
        scores = _sigmoid(F @ self.w + self.b)
        self._conf.append(float(scores.max()) if scores.size else 0.0)

        io = np.array([block_stats[b].get("io_cost", 0.0) for b in bids], dtype=np.float32)
        utility = scores - self.lam_io * io

        sorted_bids = sorted(bids)
        win = sorted_bids[-self.window:] if self.window > 0 else []  # note: lst[-0:] == all
        forced: set[int] = set(sorted_bids[: self.sink]) | set(win)
        remaining = budget - len(forced)
        if remaining <= 0:
            wts = win[::-1] + sorted_bids[: self.sink]
            seen, ordered = set(), []
            for b in wts:
                if b not in seen:
                    seen.add(b); ordered.append(b)
            return set(ordered[:budget])
        cand = [(b, float(u)) for b, u in zip(bids, utility) if b not in forced]
        cand.sort(key=lambda kv: -kv[1])
        return forced | {b for b, _ in cand[:remaining]}

    def confidence(self) -> float:
        return float(np.mean(self._conf)) if self._conf else 1.0
