"""GuardKV policy — risk-controlled, query-free KV scheduling as a SEER
:class:`seer.policy.base.KVPolicy`.

This is the deployment slot for the GuardKV design (see csp-llm
``experiments/DESIGN_v2_conformal_crosslayer.md`` and ``xqp/{budgeter,guardkv}.py``).
It differs from :class:`seer.policy.xqp.XQPPolicy` in *what sets the keep size*:

  XQPPolicy   : budget is an INPUT — greedily fill to `budget` blocks.
  GuardKVPolicy: budget is an OUTPUT — keep {b : p_b >= tau(layer)} where the
                 per-layer threshold tau was calibrated (split-conformal) so the
                 realized missed-saliency rate <= alpha. The HBM `budget` is only a
                 hard ceiling (we never exceed it; if the guarantee asks for fewer,
                 we keep fewer and free HBM).

So the operator sets a *risk* alpha offline (via xqp.budgeter.CoverageDrivenBudgeter,
saved with ``.save``); GuardKV turns it into a per-layer keep set whose miss-rate is
bounded, and the retention ratio falls out. Blocks below tau are *demoted*, not
deleted (SEER's tiering), so a future layer can recall them — and the query-free
cross-layer prefetch hint (P3) is exposed for a tier prefetcher.

The scorer is the same calibrated within+cross logistic (query view neutralized to
0.5; the offline analysis found it irrelevant). Per-layer tau is keyed by NORMALIZED
layer position and interpolated to this model's layer count, so a guarantee
calibrated on 36-layer traces transfers to any depth.

Self-contained (numpy only); SEER does not import the ``xqp`` package.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from seer.policy.base import KVPolicy


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


class GuardKVPolicy(KVPolicy):
    name = "guardkv"

    def __init__(
        self,
        weights,
        bias: float = 0.0,
        *,
        norm_curve=None,          # [(pos in [0,1], tau), ...]  from budgeter.save
        tau_global: float = 0.5,
        alpha: float = 0.10,
        sink: int = 4,
        window: int = 4,
        r_cross: float = 0.10,
        ema_decay: float = 0.9,
        history_k: int = 8,
    ) -> None:
        self.w = np.asarray(weights, dtype=np.float32).reshape(-1)
        if self.w.shape[0] != 4:
            raise ValueError(f"GuardKVPolicy expects 4 weights, got {self.w.shape}")
        self.b = float(bias)
        nc = sorted(norm_curve or [(0.0, tau_global), (1.0, tau_global)])
        self._pos = np.array([p for p, _ in nc], dtype=np.float32)
        self._tau = np.array([t for _, t in nc], dtype=np.float32)
        self.tau_global = float(tau_global)
        self.alpha = float(alpha)
        self.sink = int(sink)
        self.window = int(window)
        self.r_cross = float(r_cross)
        self.ema_decay = float(ema_decay)
        self.history_k = int(history_k)
        self._prev_topr: set[int] = set()
        self.prefetch_hint: set[int] = set()    # P3: blocks the NEXT layer will want
        self._emergent: list[float] = []        # realized retention ratio per call
        self._miss: list[float] = []            # realized miss if labels supplied

    @classmethod
    def from_ckpts(cls, scorer_path: str, budgeter_path: str, **kwargs) -> "GuardKVPolicy":
        sc = json.loads(Path(scorer_path).read_text())
        w, b = sc["weights"], sc["bias"]
        if isinstance(b, list):
            b = float(np.asarray(b))
        if np.asarray(w).ndim > 1:
            raise ValueError("GuardKVPolicy needs the shared (4,) closed form")
        bg = json.loads(Path(budgeter_path).read_text())
        return cls(
            weights=w, bias=float(b),
            norm_curve=[tuple(pt) for pt in bg.get("norm_curve", [])] or None,
            tau_global=float(bg.get("tau_global", 0.5)),
            alpha=float(bg.get("alpha", 0.10)),
            **kwargs,
        )

    def reset(self) -> None:
        self._prev_topr = set()
        self.prefetch_hint = set()
        self._emergent = []      # per-request metrics: clear so reads are request-scoped
        self._miss = []

    def _tau_at(self, layer_scalar: float) -> float:
        return float(np.interp(layer_scalar, self._pos, self._tau,
                               left=self._tau[0], right=self._tau[-1]))

    def _within_raw(self, hist, now) -> float:
        tail = list(hist)[-self.history_k:]
        if not tail:
            return float(now)
        ema = float(tail[0])
        for v in tail[1:]:
            ema = self.ema_decay * ema + (1 - self.ema_decay) * float(v)
        return ema

    def select_to_keep(self, block_stats, budget, step):
        if not block_stats:
            return set()
        bids = list(block_stats.keys())
        within_raw = np.array(
            [self._within_raw(block_stats[b].get("attn_history", []),
                              block_stats[b].get("attn_score_now", 0.0)) for b in bids],
            dtype=np.float32,
        )
        wmax = float(within_raw.max()) + 1e-9
        s_within = within_raw / wmax

        # this layer's top-r within-EMA set (= cross indicator source + prefetch hint)
        k = max(1, int(np.ceil(self.r_cross * len(bids))))
        topr_idx = np.argpartition(-within_raw, kth=min(k - 1, len(bids) - 1))[:k]
        cur_topr = {bids[i] for i in topr_idx}

        layer_scalar = float(block_stats[bids[0]].get("layer_scalar", 0.0))
        # layer 0 (no predecessor) self-references; detect it robustly as "no prev
        # hot set yet" so we don't depend on the backend normalizing layer 0 to exactly 0.
        ref_topr = cur_topr if (layer_scalar <= 1e-9 or not self._prev_topr) else self._prev_topr
        s_cross = np.array([1.0 if b in ref_topr else 0.0 for b in bids], dtype=np.float32)
        # P3: predict the NEXT layer's hot set from THIS layer's top-r (query-free)
        self.prefetch_hint = set(cur_topr)
        self._prev_topr = cur_topr

        s_query = np.full(len(bids), 0.5, dtype=np.float32)
        s_pos = np.zeros(len(bids), dtype=np.float32)  # recency view ~0 in the minimal model
        F = np.stack([s_within, s_cross, s_query, s_pos], axis=1)
        p = _sigmoid(F @ self.w + self.b)
        # expose per-block scores (for serving-side conformal calibration / logging)
        self.last_scores = {b: float(pb) for b, pb in zip(bids, p)}
        self.last_layer_scalar = layer_scalar

        # ---- budget is an OUTPUT: keep {p >= tau(layer)} -----------------------
        tau = self._tau_at(layer_scalar)
        sorted_bids = sorted(bids)
        forced: set[int] = set(sorted_bids[: self.sink])      # attention sink
        if self.window > 0:                                    # sliding window (note: lst[-0:] == all)
            forced |= set(sorted_bids[-self.window:])
        keep = {b for b, pb in zip(bids, p) if pb >= tau} | forced

        # ---- HBM ceiling: never exceed `budget` (base.py contract: |keep| <= budget) --
        if budget is not None and len(keep) > budget:
            pmap = {b: float(pb) for b, pb in zip(bids, p)}
            if budget <= len(forced):
                # even the deadline floor exceeds the ceiling: keep the highest-score
                # forced blocks (deterministic tie-break by block id) so |keep| == budget
                fs = sorted(forced, key=lambda b: (-pmap.get(b, 0.0), b))
                keep = set(fs[:budget])
            else:
                cand = [(b, pmap[b]) for b in bids if b not in forced]
                cand.sort(key=lambda kv: (-kv[1], kv[0]))
                keep = set(forced) | {b for b, _ in cand[: budget - len(forced)]}

        self._emergent.append(len(keep) / max(1, len(bids)))
        return keep

    def observe_labels(self, kept: set[int], salient_ids: set[int]) -> float:
        """Optional: if the sim reveals next-step saliency, record realized miss."""
        if not salient_ids:
            return 0.0
        miss = len(salient_ids - kept) / len(salient_ids)
        self._miss.append(float(miss))
        return float(miss)

    def emergent_budget(self) -> float:
        return float(np.mean(self._emergent)) if self._emergent else float("nan")

    def realized_miss(self) -> float:
        return float(np.mean(self._miss)) if self._miss else float("nan")
